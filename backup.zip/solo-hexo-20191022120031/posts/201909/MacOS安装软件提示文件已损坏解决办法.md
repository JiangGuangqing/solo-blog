title: MacOS 安装软件提示文件已损坏解决办法
date: '2019-09-05 14:04:43'
updated: '2019-09-05 14:04:43'
tags: [MacOS]
permalink: /articles/2019/09/05/1567663482915.html
---
打开终端工具输入命令

> sudo spctl --master-disable

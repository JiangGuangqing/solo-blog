title: Linux 设置开机自动启动 Chromium 浏览器并访问指定网址
date: '2019-10-07 16:18:11'
updated: '2019-10-07 16:18:11'
tags: [Linux]
permalink: /articles/2019/10/07/1570436291093.html
---
![](https://img.hacpai.com/bing/20180129.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

**1,设置自动启动**
执行命令

```
cd  ~/.config/autostart/
```

在[autostart]目录中新建名为 my.desktop 的文件:

```
sudo vim my.desktop
```

在新建的文件里写入如下内容,网址更换成要访问的地址：

```
​[Desktop Entry]

Type=Application

​Exec=chromium-browser --disable-popup-blocking —incognito --no-first-run --disable-desktop-notifications --kiosk "[http://www.xxx.com/](http://www.xxx.com/)"
```

保存后。重启。
sudo reboot

**2,电脑意外关机是屏蔽浏览器错误提示**
在执行下面的操作之前，要确保你的浏览器已经正常关闭。
将文件权限设置成 444

```
chmod 444 ~/.config/chromium/Default/Preferences
```

忽略所有对该文件权限之类的更改

```
chattr +i ~/.config/chromium/Default/Preferences
```

**在 Ubuntu 系统中开机自动启动 chromium 时会提示输入密码解决办法**
在终端中执行命令
``  seahorse ``
在弹出新界面左侧面板中，右击“默认密钥环”，并选择“修改密码”。
在设置“默认”密钥环新密码的密码框中留空。
在询问是否不加密存储密码对话框中点击“继续”。

设置完成。

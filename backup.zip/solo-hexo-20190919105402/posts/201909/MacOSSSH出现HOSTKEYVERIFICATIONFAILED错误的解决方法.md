title: MacOS SSH出现HOST KEY VERIFICATION FAILED错误的解决方法
date: '2019-09-12 15:39:23'
updated: '2019-09-12 15:39:23'
tags: [MacOS]
permalink: /articles/2019/09/12/1568273963655.html
---
![](https://img.hacpai.com/bing/20180203.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

打开终端工具输入命令

```

cd ~/.ssh

rm known_hosts

```

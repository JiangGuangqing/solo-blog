title: Linux 将系统 PHP 设置为宝塔面板安装的 PHP
date: '2019-10-14 13:28:50'
updated: '2019-10-14 13:28:50'
tags: [Linux]
permalink: /articles/2019/10/14/1571030930851.html
---
![](https://img.hacpai.com/bing/20190306.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

登录SSH，输入下列命令：
```
rm -f /usr/bin/php
```
```
ln -sf /www/server/php/71(php版本)/bin/php /usr/bin/php
```

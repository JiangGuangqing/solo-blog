title: 宝塔面板使用 webhook 自动同步码云代码
date: '2019-11-21 13:20:36'
updated: '2019-12-10 09:46:09'
tags: [Linux, git]
permalink: /articles/2019/11/21/1574313636658.html
---
![](https://img.hacpai.com/bing/20171205.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

###  宝塔面板安装 webhook
###  添加 shell脚本
![image.png](https://img.hacpai.com/file/2019/12/image-e2b77c1a.png)

```
#!/bin/bash
echo ""
#输出当前时间
date --date='0 days ago' "+%Y-%m-%d %H:%M:%S"
echo "Start"
#判断宝塔WebHook参数是否存在
if [ ! -n "$1" ];
then 
          echo "param参数错误"
          echo "End"
          exit
fi
#git项目路径
gitPath="/www/wwwroot/xxx"
#git 网址
gitHttp="https://gitee.com/web/xxx.git"

echo "Web站点路径：$gitPath"

#判断项目路径是否存在
if [ -d "$gitPath" ]; then
        cd $gitPath
        #判断是否存在git目录
        if [ ! -d ".git" ]; then
                echo "在该目录下克隆 git"
                git clone $gitHttp gittemp
                mv gittemp/.git .
                rm -rf gittemp
        fi
        #拉取最新的项目文件
        git reset --hard origin/master
        git pull origin master
        #设置目录权限
        chown -R www:www $gitPath
        echo "End"
        exit
else
        echo "该项目路径不存在"
        echo "End"
        exit
fi
```
### 配置码云
![image.png](https://img.hacpai.com/file/2019/12/image-425ce625.png)


**填写 URL, 面板替换成你的宝塔面板地址,access_key替换成秘钥；密码留空**


![image.png](https://img.hacpai.com/file/2019/12/image-8bbce0b3.png)

**点击添加按钮，配置完成**










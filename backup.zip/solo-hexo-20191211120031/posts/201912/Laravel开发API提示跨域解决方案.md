title: Laravel 开发 API 提示跨域解决方案
date: '2019-12-10 17:57:15'
updated: '2019-12-10 17:57:15'
tags: [PHP, Laravel]
permalink: /articles/2019/12/10/1575971835846.html
---
![](https://img.hacpai.com/bing/20190506.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### 创建中间件
```
php artisan make:middleware Cors
```

#### 允许跨域
```
public function handle($request, Closure $next)
{
    return $next($request)
        ->header('Access-Control-Allow-Origin', '*')
        ->header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
}
```

#### 在 `app/Http/Kernel.php`文件中配置中间件
```
\App\Http\Middleware\Cors::class,
```


title: PhpStorm 配置 laravel 框架代码提示
date: '2019-10-22 09:46:29'
updated: '2019-10-22 09:46:29'
tags: [PHP, composer, Laravel]
permalink: /articles/2019/10/22/1571708789104.html
---
![](https://img.hacpai.com/bing/20190508.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

 ### 安装 Laravel-ide-helper 扩展
```
composer require barryvdh/laravel-ide-helper
```

### 在 `config/app.php`添加provider
``` php
Barryvdh\LaravelIdeHelper\IdeHelperServiceProvider::class,
```

### 使用
```
php artisan ide-helper:generate - 为 Facades 生成 phpDocs 注释
php artisan ide-helper:models - 为 Models 生成 phpDocs 注释
php artisan ide-helper:meta - 为 PhpStorm 生成类路径提示文件
```

### 在`.gitignore`文件中添加下列配置
```
.idea
_ide_helper.php
_ide_helper_models.php
.phpstorm.meta.php
```

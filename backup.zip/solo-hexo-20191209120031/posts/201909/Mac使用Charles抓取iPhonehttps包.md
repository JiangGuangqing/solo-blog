title: Mac使用 Charles 抓取 iPhone https包
date: '2019-09-11 15:55:25'
updated: '2019-09-11 15:55:56'
tags: [MacOS]
permalink: /articles/2019/09/11/1568188525537.html
---
![](https://img.hacpai.com/bing/20181109.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

#### 第一步：配置Charles，允许抓取https包

Proxy->SSL Proxying Settings…，勾选Enable SSL Proxying，Add一个location，通过通配符* 抓取所有域名的https。（如果想只抓取某个域名的，设置具体域名的即可）
![image.png](https://img.hacpai.com/file/2019/09/image-c5fb473e.png)


#### 第二步：Mac 安装 SSL 证书

Help->SSL Proxying->Install Charles ROOT Certificate
![image.png](https://img.hacpai.com/file/2019/09/image-94897096.png)


#### 第三步：iPhone 安装 SSL 证书

Help->SSL Proxying->Install Charles ROOT Certificate on a Mobile Device or Remote Browser

![image.png](https://img.hacpai.com/file/2019/09/image-b1ae3234.png)


点击后出现弹窗，将 iPhone 和 Mac 连接到同一局域网下，设置 iPhone 的 WIFI 代理为 `192.168.110.127:8888`,然后打开Safari 浏览器访问`chls.pro/ssl`安装证书。

![image.png](https://img.hacpai.com/file/2019/09/image-878b6597.png)


在 IOS10 以上的系统中，需要点开 设置->通用->关于本机->证书信任设置 将证书启用完全信任。

![image.png](https://img.hacpai.com/file/2019/09/image-7c5e1cf2.png)

**证书安装完成后即可在Charles上抓取HTTPS的请求。**

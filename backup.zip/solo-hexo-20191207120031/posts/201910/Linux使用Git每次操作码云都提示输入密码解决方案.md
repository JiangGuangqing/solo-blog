title: Linux 使用 Git每次操作码云都提示输入密码解决方案
date: '2019-10-09 13:15:11'
updated: '2019-10-09 13:15:24'
tags: [Linux, git]
permalink: /articles/2019/10/09/1570598111006.html
---
![](https://img.hacpai.com/bing/20190329.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

**将服务器 Git 远程协议修改成 SSH 即可**

#### 1.在本机上生成 SSH 公钥

 ``` 
ssh-keygen -t rsa -C “码云注册邮箱地址” 
```

#### 2.将公钥添加到码云
将 id_ras.pub 文件里的内容复制出来。
 ```
cat ~/.ssh/id_rsa.pub
 ```
![image.png](https://img.hacpai.com/file/2019/10/image-d3059344.png)
#### 3.修改为ssh协议认证
```
git remote rm origin
git remote add origin git@gitee.com:xxx/xxx.git
```

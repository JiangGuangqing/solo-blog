title: laravel 使用阿里云语音合成 API
date: '2019-10-21 14:45:47'
updated: '2019-10-21 14:50:56'
tags: [阿里云, Laravel, PHP]
permalink: /articles/2019/10/21/1571640347241.html
---
![](https://img.hacpai.com/bing/20190316.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 获取服务鉴权 Token

引入阿里云 SDK

```
composer require alibabacloud/sdk
```

使用阿里云 RAM 账号的 AccessKey ID 和 AccessKey Secret 进行鉴权

```
use AlibabaCloud\Client\AlibabaCloud;
use AlibabaCloud\Client\Exception\ClientException;
use AlibabaCloud\Client\Exception\ServerException;

public function getToken()
{
	/**
	 * 第一步：设置一个全局客户端
	 * 使用阿里云RAM账号的AccessKey ID和AccessKey Secret进行鉴权
	 */
	AlibabaCloud::accessKeyClient(
		"AccessKey ID",
		"AccessKey Secret")
		->regionId("cn-shanghai")
		->asDefaultClient();
	try {
		$response = AlibabaCloud::nlsCloudMeta()
			->v20180518()
			->createToken()
			->request();
		$token = $response["Token"];
		if ($token != NULL) {
			return $token['Id'];
		} else {
			return "token 获取失败";
		}
	} catch (ClientException $exception) {
		// 获取错误消息
		print_r($exception->getErrorMessage());
	} catch (ServerException $exception) {
		// 获取错误消息
		print_r($exception->getErrorMessage());
	}
}
```

## 调用语音合成接口
```
public function index()
{
	$appkey = "智能语音交互的 APPkey";
	$token = $this->getToken();
	//文字内容
	$text = "首先，这是心理上的原因。害羞的人往往妄自菲薄，十分自卑。其中，有的对自己缺乏信心，过分考虑自己给别人的印象，总是担心别人看不起自己;有的在大庭广众之中发言遭到过冷淡，或在交往中遇到过挫折，从此一蹶不振。";
	$textUrlEncode = urlencode($text);
	$textUrlEncode = preg_replace('/\+/', '%20', $textUrlEncode);
	$textUrlEncode = preg_replace('/\*/', '%2A', $textUrlEncode);
	$textUrlEncode = preg_replace('/%7E/', '~', $textUrlEncode);
	//文件保存地址
	$audioSaveFile = "syAudio.wav";
	$format = "wav";
	$sampleRate = 16000;
	$this->processGETRequest($appkey, $token, $textUrlEncode, $audioSaveFile, $format, $sampleRate);
}

public function processGETRequest($appkey, $token, $text, $audioSaveFile, $format, $sampleRate)
{
	$url = "https://nls-gateway.cn-shanghai.aliyuncs.com/stream/v1/tts";
	$url = $url . "?appkey=" . $appkey;
	$url = $url . "&token=" . $token;
	$url = $url . "&text=" . $text;
	$url = $url . "&format=" . $format;
	$url = $url . "&sample_rate=" . strval($sampleRate);
	$url = $url . "&voice=" . "sitong";

	$curl = curl_init();
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
	/**
	 * 设置HTTPS GET URL
	 */
	curl_setopt($curl, CURLOPT_URL, $url);
	/**
	 * 设置返回的响应包含HTTPS头部信息
	 */
	curl_setopt($curl, CURLOPT_HEADER, TRUE);
	/**
	 * 发送HTTPS GET请求
	 */
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
	$response = curl_exec($curl);
	if ($response == FALSE) {
		print "curl_exec failed!\n";
		curl_close($curl);
		return;
	}
	/**
	 * 处理服务端返回的响应
	 */
	$headerSize = curl_getinfo($curl, CURLINFO_HEADER_SIZE);
	$headers = substr($response, 0, $headerSize);
	$bodyContent = substr($response, $headerSize);
	curl_close($curl);
	if (stripos($headers, "Content-Type: audio/mpeg") != FALSE || stripos($headers, "Content-Type:audio/mpeg") != FALSE) {
		file_put_contents($audioSaveFile, $bodyContent);
		return "success";
	} else {
		return "The GET request failed: " . $bodyContent;
	}
}
```

title: 使用宝塔面板安装 solo 博客
date: '2019-10-07 15:51:08'
updated: '2019-10-07 15:51:08'
tags: [Linux]
permalink: /articles/2019/10/07/1570434668186.html
---
![](https://img.hacpai.com/bing/20190224.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### Solo 博客介绍：[https://github.com/b3log/solo](https://github.com/b3log/solo)

### 安装

#### 1. 使用宝塔面板安装 nginx,mysql,docker

#### 2. 直接运行以下命令

```
docker pull b3log/solo
```

```
docker run --detach  --restart=always --name solo --network=host \

 --env RUNTIME_DB="MYSQL" \

 --env JDBC_USERNAME="solo" \

 --env JDBC_PASSWORD="123456" \

 --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \

 --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \

 b3log/solo --listen_port=8080 --server_scheme=https --server_host=aumc.cc --server_port=
```

上面的命令建议手敲，免得出错，参数说明

* `--env JDBC_USERNAME="solo"` 将 Solo 换成你的数据库用户名
* `--env JDBC_PASSWORD="123456"` 将 123456 换成你的密码
* ` --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC"` 将 MySQL 地址换成你的数据库地址
* `--listen_port=8080` 监听的端口
* `--server_scheme=https` 请求方式，这里我们使用 https,也可以使用 http
* `--server_host=aumc.cc` 你的域名，如果你没有域名可以写 ip 地址

#### 3.nginx 配置

在宝塔面板添加网站绑定域名(这里我绑定的域名是 aumc.cc)，并设置 HTTPS，然后设置反向代理，代理地址为 [http://aumc.cc:8080](http://aumc.cc:8080) ，然后在浏览器里访问 [https://aumc.cc](https://aumc.cc) 即可。

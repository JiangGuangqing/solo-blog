title: laravel-admin 手动刷新后左侧导航不选中解决方案
date: '2019-10-16 10:29:26'
updated: '2019-10-16 10:33:08'
tags: [Laravel]
permalink: /articles/2019/10/16/1571192966273.html
---
![](https://img.hacpai.com/bing/20181122.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

这是由于 laravel-admin 采用 pjax 加载页面引起的。   
解决方案：在全局 js 加入列代码
```javascript
$('.sidebar-menu li:not(.treeview) > a').on('click', function () {
   var $parent = $(this).parent().addClass('active');
   $parent.siblings('.treeview.active').find('> a').trigger('click');
   $parent.siblings().removeClass('active').find('li').removeClass('active');
});
```
``` javascript
$('.sidebar-menu a').each(function () {
    if (this.href === GetUrlPara()) {
        $(this).parent().addClass('active')
            .closest('.treeview-menu').addClass('.menu-open')
            .closest('.treeview').addClass('active');
    }
});
```

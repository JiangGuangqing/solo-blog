title: 删除所有Aliyun监控进程，屏蔽云盾功能
date: '2019-09-12 14:36:58'
updated: '2019-09-12 14:36:58'
tags: [Linux, 阿里云]
permalink: /articles/2019/09/12/1568270217877.html
---
![](https://img.hacpai.com/bing/20190423.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

**大家都不想自己的所作所为都被监控着，所以我们需要让他的监控失效，卸载监控。**

#### 卸载AliYunDun

```

wget http://update.aegis.aliyun.com/download/uninstall.sh

chmod +x uninstall.sh

./uninstall.sh

wget http://update.aegis.aliyun.com/download/quartz_uninstall.sh

chmod +x quartz_uninstall.sh

./quartz_uninstall.sh

```

##### 删除AliYunDun残留

```

pkill aliyun-service

rm -fr /etc/init.d/agentwatch /usr/sbin/aliyun-service

rm -rf /usr/local/aegis*

```

```

iptables -I INPUT -s 140.205.201.0/28 -j DROP

iptables -I INPUT -s 140.205.201.16/29 -j DROP

iptables -I INPUT -s 140.205.201.32/28 -j DROP

iptables -I INPUT -s 140.205.225.192/29 -j DROP

iptables -I INPUT -s 140.205.225.200/30 -j DROP

iptables -I INPUT -s 140.205.225.184/29 -j DROP

iptables -I INPUT -s 140.205.225.183/32 -j DROP

iptables -I INPUT -s 140.205.225.206/32 -j DROP

iptables -I INPUT -s 140.205.225.205/32 -j DROP

iptables -I INPUT -s 140.205.225.195/32 -j DROP

iptables -I INPUT -s 140.205.225.204/32 -j DROP

```

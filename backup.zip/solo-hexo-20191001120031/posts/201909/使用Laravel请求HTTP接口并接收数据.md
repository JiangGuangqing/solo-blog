title: 使用Laravel请求HTTP接口并接收数据
date: '2019-09-04 19:24:58'
updated: '2019-09-09 10:41:03'
tags: [Laravel, PHP]
permalink: /articles/2019/09/04/1567596298112.html
---
### 安装 Guzzle 处理 HTTP 请求

```
 composer require guzzlehttp/guzzle
```  

### 推送数据
```
public function sendData()
{   
    //接口域名
    $url = 'http://www.xxx.com/';
    //路由
    $route = 'getData';
    //数据，多维数组
    $data = array(
        [
            "deviceId" => "1",
            "bookName" => "大熊与钢琴"
        ],
        [
            "bookId" => "456",
            "bookName" => "三只猪"
        ]
    );

    $client = new \GuzzleHttp\Client(['base_uri' => $url]);
    $res = $client->request('POST', $route,
        [
            'json' => $data,
            'headers' => [
                'Content-type' => 'application/json',
                "Accept" => "application/json"]
        ]);
    $msg = $res->getBody()->getContents();

    return $msg;
}
```

### 接收数据 
```
public function getData(Request $request)
{   
    $data = $request->all();
    
    $msg['status_code'] = 200;
    $msg['message'] = "操作成功";
    return json_encode($msg);
}
```

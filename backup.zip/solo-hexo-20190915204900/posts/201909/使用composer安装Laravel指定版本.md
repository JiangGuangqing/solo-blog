title: 使用composer 安装Laravel 指定版本
date: '2019-09-09 11:10:23'
updated: '2019-09-09 11:10:23'
tags: [PHP, Laravel]
permalink: /articles/2019/09/09/1567998622948.html
---
通过在终端中运行 create-project 命令来安装：

```

composer create-project --prefer-dist laravel/laravel blog "5.5.*"

```

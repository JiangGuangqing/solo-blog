title: 使用 composer 时提示putenv() has been disabled 解决方案
date: '2019-09-10 13:59:37'
updated: '2019-09-10 13:59:37'
tags: [PHP, composer]
permalink: /articles/2019/09/10/1568095176971.html
---
在`php.ini`文件中，搜索 `disable_functions=` ,删除 `putenv` 即可。

**如果使用宝塔面板**

找到软件商城 PHP 设置，在`禁用函数`一栏删除`putenv`即可。
